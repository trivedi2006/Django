# urls.py

from rest_framework.routers import DefaultRouter
from .views import CourseViewSet

router = DefaultRouter()

router.register('courses', CourseViewSet)

urlpatterns = router.urls