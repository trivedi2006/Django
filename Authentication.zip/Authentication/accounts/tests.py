from django.test import TestCase
from django.urls import reverse


class SignupViewTests(TestCase):
    def test_signup_with_invalid_data_returns_form_page(self):
        response = self.client.post(reverse("signup"), {})

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Signup")
