from django.shortcuts import render,redirect,get_object_or_404
from .models import Employee
from .forms import EmployeeForm
# Create your views here.

def home(request):
    name = request.GET.get('search')
    if name:
        i = Employee.objects.filter(name__icontains = name)
    else:
        i = Employee.objects.all()
    return render(request , 'home.html' , {'employee':i})

def add(request):
    if request.method =="POST":
        form = EmployeeForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = EmployeeForm()
    return render(request, 'add_employee.html', {'form': form})

def update(request,id):
    employee = get_object_or_404(Employee,id=id)
    if request.method =="POST":
        form  = EmployeeForm(request.POST,instance=employee)
        if form.is_valid():
                form.save()
                return redirect('home')
    else:
        form = EmployeeForm(instance=employee)
    return render(request,'update_employee.html',{'form':form})

def delete(request,id):
    employee = get_object_or_404(Employee,id=id)
    if request.method =="POST":
        employee.delete()
        return redirect('home')
    else:
        return render(request,'delete_employee.html',{'employee':employee})
    
def detail(request,id):
    employee =  get_object_or_404(Employee,id=id)
    return render(request,'detail_employee.html',{'employee':employee})