from django.urls import path
from .views import home,add,update,delete,detail

urlpatterns=[
    path("",home,name='home'),
    path("add/",add,name='add'),
    path("update/<int:id>/",update,name='update_employee'),
    path("delete/<int:id>/",delete,name='delete_employee'),
    path("detail/<int:id>/",detail,name='detail_employee')
]